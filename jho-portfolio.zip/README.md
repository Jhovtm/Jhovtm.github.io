# Portfólio da Jho

Site estático feito com HTML, CSS e JavaScript, baseado no layout do Canva.

## Como abrir

Abra `index.html` no navegador. Para editar e visualizar mudanças enquanto trabalha, abra esta pasta no VS Code e use a extensão Live Server.

## Estrutura

- `index.html`: conteúdo e estrutura das seções
- `styles.css`: cores, layout e comportamento responsivo
- `script.js`: menu de navegação para telas pequenas
- `assets/`: imagens utilizadas no site

As fontes DM Sans e Playfair Display são carregadas do Google Fonts quando há conexão com a internet; o site usa fontes alternativas caso elas não carreguem.
